void printshellcmd(Shellcmd *shellcmd);
void printcmdlist(Cmd *p);
