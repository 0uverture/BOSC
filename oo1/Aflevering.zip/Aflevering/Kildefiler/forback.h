/* 

   Opgave 1

   forback.h

 */

#ifndef _FORBACK_H
#define _FORBACK_H

int foregroundcmd(char *, char*[], char *, char *);
int backgroundcmd(char *, char*[], char *, char *);

#endif
