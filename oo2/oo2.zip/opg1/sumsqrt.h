#ifndef SUMSQRT_H
#define SUMSQRT_H

double sum_sqrt(int n, int tnum);

#endif