Usage:
sumsqrt [N] [THREADS]

N and THREADS must be larger than 0.
N must be larger than THREADS.